// Vercel serverless function. Writes one row to Google Sheets; mock mode if unconfigured.
const txt = (v, n = 60) => { const s = String(v ?? '').slice(0, n).replace(/[\r\n]/g, ' '); return /^[=+\-@]/.test(s) ? "'" + s : s; };
const num = (v, max = 1e9) => { const n = Number(v); return Number.isFinite(n) && n >= 0 && n <= max ? n : null; };
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed.' });
  try {
    const b = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const keys = ['age', 'monthlyIncome', 'monthlyExpenses', 'existingEmi', 'creditScore', 'loanAmount', 'loanTenure', 'eligibilityScore'];
    const n = keys.map(k => num(b[k], k === 'age' ? 120 : 1e9));
    if (n.includes(null)) return res.status(400).json({ error: 'Invalid record.' });
    const { GOOGLE_SERVICE_ACCOUNT_EMAIL: email, GOOGLE_PRIVATE_KEY: pk, GOOGLE_SHEET_ID: id } = process.env;
    if (!email || !pk || !id) return res.status(200).json({ mock: true, message: 'Sheets not configured; nothing stored.' });
    const { google } = require('googleapis');
    const auth = new google.auth.JWT(email, null, pk.replace(/\\n/g, '\n'), ['https://www.googleapis.com/auth/spreadsheets']);
    const sheets = google.sheets({ version: 'v4', auth });
    await sheets.spreadsheets.values.append({
      spreadsheetId: id, range: 'Sheet1!A:M', valueInputOption: 'RAW',
      requestBody: { values: [[new Date().toISOString(), txt(b.name), n[0], txt(b.employmentType), n[1], n[2], n[3], n[4], n[5], n[6], n[7], txt(b.eligibilityResult), txt(b.riskLevel)]] }
    });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: 'Could not save the record.' });
  }
};
