exports.handler=require('../lib/adapt.js')(require('../../api/financial-advice.js'));
