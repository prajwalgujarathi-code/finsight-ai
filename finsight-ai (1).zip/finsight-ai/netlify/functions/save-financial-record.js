exports.handler=require('../lib/adapt.js')(require('../../api/save-financial-record.js'));
