# FinSight AI – Intelligent Financial Decision Platform

## 1. Overview
A dark glassmorphism fintech web app for loan eligibility estimates, credit analysis, EMI calculation and educational AI tips. All outputs are estimates for education only, not bank approvals, bureau reports or financial advice.

## 2. Features
Eligibility checker with a transparent 100-point model, credit score analyzer with animated meter, live EMI calculator (₹ formatting), Claude-powered advisor, dashboard, demo mode, accessibility (labels, focus states, ARIA alerts, reduced motion).

## 3. Technology Stack
HTML5, CSS3, vanilla JS (ES6+); Node.js serverless functions; Anthropic Messages API; Google Sheets API.

## 4. System Architecture
```mermaid
flowchart TD
  U[User] --> F[Input form] --> V[JS validation] --> A[Analysis engine]
  A --> L[Loan analysis] & C[Credit analysis] & E[EMI calculator]
  L & C & E --> D[Dashboard]
  A --> AI[AI advisor] --> API[/api/financial-advice/] --> CL[Claude API]
  CL --> D
  A --> S[/api/save-financial-record/] --> GS[Google Sheets]
```

## 5. Folder Structure
```
finsight-ai/
├── index.html  style.css  script.js
├── api/financial-advice.js  api/save-financial-record.js
├── netlify/functions/*  netlify/lib/adapt.js  netlify.toml
├── assets/icons/  package.json  .env.example  README.md
```
`api/` is the Vercel convention. Netlify needs `netlify/functions`, so thin wrappers reuse the same handlers.

## 6–7. Installation and local development
`npm install`, copy `.env.example` to `.env`, then `npx vercel dev` (or `npx netlify dev`). Opening `index.html` directly works in Demo Mode only.

## 8. Claude API configuration
Create a key in the Anthropic Console and set `ANTHROPIC_API_KEY` in your host's environment settings. The key is only read in `api/financial-advice.js`.

## 9. Google Sheets configuration
Create a Google Cloud service account, enable the Sheets API, share your sheet with the service-account email (Editor), and put the header row Timestamp, Name, Age, Employment Type, Monthly Income, Monthly Expenses, Existing EMI, Credit Score, Loan Amount, Loan Tenure, Eligibility Score, Eligibility Result, Risk Level in `Sheet1`. Without credentials the endpoint runs in mock mode and stores nothing.

## 10. Environment variables
See `.env.example`. Never commit `.env`.

## 11. Demo mode
Click "Try Demo". Sample data fills every form, no network calls are made, and results are labeled demo-generated.

## 12. Deployment
**Vercel:** push to GitHub, import the repo, add the environment variables, deploy. **Netlify:** import the repo (publish directory `.`, functions from `netlify.toml`), add the environment variables, deploy. Use "Clear cache and deploy" after changing variables.

## 13. Security practices
Secrets only in server env vars; server-side validation; spreadsheet formula-injection guard; no stack traces returned; optional, consent-based saving; HTTPS via the host. Add rate limiting before public launch.

## 14. Limitations
Rule-based model not calibrated on lender data; no bureau access; no authentication; records can only be deleted manually in the sheet; not reviewed against any regulation.

## 15. Future enhancements
Authentication, secure database, bureau integration, ML loan prediction, fraud detection, PDF and email reports, goal tracking, investment education, expense categorization, bank APIs, financial planning, multi-language support.

## Testing checklist
- EMI: ₹10,00,000 at 10.75% for 5 years ≈ ₹21,6xx; 0% rate gives amount ÷ months; 0, negative or blank values show errors.
- Eligibility: high income + score 780 → High; income ₹20,000 + EMI ₹9,000 + score 600 → Low; age 17 or score 950 rejected.
- Credit: score 300 and 900 edges; utilization 10% vs 90%.
- Forms: empty, negative, letters, mobile keyboards, no horizontal scroll at 360px.
- AI: stop the API (falls back with a notice); missing key → fallback; empty response → fallback.
- Storage: with and without Sheets variables.
