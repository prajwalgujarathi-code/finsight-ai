'use strict';
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const state = { demo: false, loan: null, credit: null, emi: null };
const DEMO_TAG = () => state.demo ? '<span class="lab">Demo-generated sample data</span>' : '';

/* ---------- Finance math ---------- */
function calcEMI(P, annual, n) {
  if (!(P > 0) || !(n > 0)) return 0;
  const r = annual / 1200;
  if (r === 0) return P / n;
  const f = Math.pow(1 + r, n);
  return P * r * f / (f - 1);
}
function loanCapacity(maxEmi, annual, n) {
  if (maxEmi <= 0 || n <= 0) return 0;
  const r = annual / 1200;
  if (r === 0) return maxEmi * n;
  const f = Math.pow(1 + r, n);
  return maxEmi * (f - 1) / (r * f);
}

/* ---------- Validation ---------- */
function validateForm(form) {
  let ok = true, first = null;
  form.querySelectorAll('[data-label]').forEach(el => {
    const err = document.getElementById('e-' + el.id);
    const v = el.value.trim(), label = el.dataset.label;
    let msg = '';
    if (!v) msg = `Please enter ${label}.`;
    else if (el.type === 'number') {
      const n = Number(v), min = el.dataset.min, max = el.dataset.max;
      if (!Number.isFinite(n)) msg = `Please enter ${label}.`;
      else if ((min !== undefined && n < +min) || (max !== undefined && n > +max)) msg = `Enter ${label} between ${(+min).toLocaleString('en-IN')} and ${(+max).toLocaleString('en-IN')}.`;
    }
    if (err) err.textContent = msg;
    el.setAttribute('aria-invalid', String(!!msg));
    if (err) el.setAttribute('aria-describedby', err.id);
    if (msg) { ok = false; first = first || el; }
  });
  if (first) first.focus();
  return ok;
}
const num = id => Number($('#' + id).value);
const list = (title, items) => items.length ? `<h4>${title}</h4><ul>${items.map(i => `<li>${esc(i)}</li>`).join('')}</ul>` : '';
function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
const tone = (v, good, mid) => v >= good ? 'ok' : v >= mid ? 'wn' : 'bad';

/* ---------- Loan eligibility ---------- */
function analyzeLoan(d) {
  const rate = 10.5, n = Math.round(d.tenure * 12);
  const disposable = d.income - d.expenses - d.emi;
  const newEmi = calcEMI(d.amount, rate, n);
  const dti = (d.emi + newEmi) / d.income * 100;
  const maxEmi = Math.max(0, Math.min(d.income * 0.5 - d.emi, disposable * 0.8));
  const capacity = loanCapacity(maxEmi, rate, n);
  let s = 0; const pos = [], risk = [], tips = [];
  if (d.score >= 750) { s += 30; pos.push('Strong credit score (750+)'); }
  else if (d.score >= 700) { s += 24; pos.push('Good credit score (700–749)'); }
  else if (d.score >= 650) { s += 15; risk.push('Moderate credit score (650–699)'); tips.push('Reduce card utilization and avoid missed payments to move above 700.'); }
  else { s += 5; risk.push('Credit score below 650'); tips.push('Focus on on-time payments and lowering utilization before applying.'); }
  if (dti <= 30) { s += 30; pos.push('Low EMI-to-income ratio after this loan'); }
  else if (dti <= 40) { s += 22; }
  else if (dti <= 50) { s += 12; risk.push('EMI burden is 40–50% of income'); }
  else { s += 3; risk.push('EMI burden above 50% of income'); tips.push('Choose a smaller amount or a longer tenure to lower the EMI.'); }
  if (disposable <= 0) { risk.push('No disposable income after expenses and EMIs'); tips.push('Cut monthly expenses or clear an existing loan first.'); }
  if (d.amount <= capacity) { s += 15; pos.push('Requested amount is within estimated capacity'); }
  else if (d.amount <= capacity * 1.25) { s += 7; risk.push('Requested amount is slightly above estimated capacity'); }
  else { risk.push('Requested amount is well above estimated capacity'); tips.push(`Consider a loan near ${inr(capacity)} or a co-applicant.`); }
  const empPts = { 'Salaried': 10, 'Self Employed': 7, 'Business Owner': 7, 'Other': 4, 'Student': 2 }[d.emp] ?? 4;
  s += empPts; (empPts >= 7 ? pos : risk).push(`Employment type: ${d.emp}`);
  if (d.exp >= 2) { s += 5; pos.push('Two or more years of experience'); } else { risk.push('Less than two years of experience'); }
  if (d.age >= 23 && d.age <= 58) s += 10; else if ((d.age >= 21 && d.age < 23) || (d.age > 58 && d.age <= 62)) { s += 6; risk.push('Age is near lender limits'); } else { s += 2; risk.push('Age outside the typical range'); }
  if (d.loans >= 3) { risk.push('Three or more existing loans'); tips.push('Consolidating or closing small loans can improve approval odds.'); }
  const status = s >= 70 ? 'High' : s >= 45 ? 'Moderate' : 'Low';
  if (!tips.length) tips.push('Keep utilization low and compare offers from several lenders.');
  return { s, status, capacity, dti, newEmi, disposable, pos, risk, tips, score: d.score };
}
function renderLoan(r) {
  const c = r.status === 'High' ? 'ok' : r.status === 'Moderate' ? 'wn' : 'bad';
  $('#loanOut').innerHTML = `${DEMO_TAG()}<span class="lab">Estimated Eligibility – Educational/Informational Only</span>
  <div class="big ${c}">${r.status} Estimated Eligibility</div>
  <div class="kv"><div><small>Eligibility score</small><b>${r.s}/100</b></div><div><small>Estimated loan capacity</small><b>${inr(r.capacity)}</b></div>
  <div><small>Debt-to-income ratio</small><b>${r.dti.toFixed(1)}%</b></div><div><small>Estimated EMI for request</small><b>${inr(r.newEmi)}</b></div>
  <div><small>Disposable income</small><b>${inr(r.disposable)}</b></div></div>
  ${list('Positive factors', r.pos)}${list('Risk factors', r.risk)}${list('Suggestions', r.tips)}`;
}

/* ---------- Credit analyzer ---------- */
function analyzeCredit(d) {
  const cat = d.score >= 750 ? 'Excellent' : d.score >= 700 ? 'Good' : d.score >= 650 ? 'Fair' : 'Needs Improvement';
  let pts = d.score >= 750 ? 0 : d.score >= 700 ? 1 : d.score >= 650 ? 2 : 4;
  const pos = [], risk = [], tips = [];
  if (d.util <= 30) pos.push('Low credit utilization'); else { pts += d.util > 60 ? 2 : 1; risk.push(`High utilization (${d.util}%)`); tips.push('Keep utilization below 30% of your limits.'); }
  if (d.pay === 0) pos.push('Consistent on-time payments'); else { pts += d.pay + 1; risk.push('Late payments reported'); tips.push('Set up auto-pay so no EMI or card bill is missed.'); }
  if (d.inq >= 4) { pts += 1; risk.push('Many recent inquiries'); tips.push('Avoid new applications for a few months.'); } else pos.push('Few recent inquiries');
  if (d.loans >= 4) { pts += 1; risk.push('Several active loans'); tips.push('Pay down smaller loans to reduce obligations.'); }
  if (d.acc >= 3) pos.push('Healthy mix of credit accounts');
  if (d.score >= 750) pos.push('Score is in the top band');
  if (!tips.length) tips.push('Maintain current habits and review your report yearly.');
  return { cat, score: d.score, risk: pts <= 2 ? 'Low' : pts <= 5 ? 'Medium' : 'High', pos, risk_f: risk, tips };
}
const catColor = c => ({ Excellent: 'var(--ok)', Good: 'var(--ac)', Fair: 'var(--wn)' }[c] || 'var(--bad)');
function renderCredit(r) {
  const C = 2 * Math.PI * 54, off = C * (1 - (r.score - 300) / 600);
  $('#creditOut').innerHTML = `${DEMO_TAG()}
  <div class="meter"><svg viewBox="0 0 120 120" width="170" height="170" aria-hidden="true"><circle class="c" cx="60" cy="60" r="54"/><circle class="p" id="arc" cx="60" cy="60" r="54" stroke="${catColor(r.cat)}" stroke-dasharray="${C}" stroke-dashoffset="${C}"/></svg>
  <div role="img" aria-label="Credit score ${r.score}, ${r.cat}"><b>${r.score}</b><span style="color:${catColor(r.cat)}">${r.cat.toUpperCase()}</span></div></div>
  <div class="kv"><div><small>Category</small><b>${r.cat}</b></div><div><small>Estimated risk</small><b class="${r.risk === 'Low' ? 'ok' : r.risk === 'Medium' ? 'wn' : 'bad'}">${r.risk}</b></div></div>
  ${list('Positive factors', r.pos)}${list('Risk factors', r.risk_f)}${list('Improvement suggestions', r.tips)}
  <p class="muted">Based only on the values you entered. No bureau data was accessed.</p>`;
  const arc = $('#arc'); requestAnimationFrame(() => requestAnimationFrame(() => arc.style.strokeDashoffset = off));
}

/* ---------- EMI ---------- */
function updateEMI() {
  const f = $('#emiForm');
  if (!validateForm(f)) { $('#emiOut').innerHTML = '<p class="muted">Fix the highlighted fields to see the EMI.</p>'; return; }
  const P = num('m-amt'), rate = num('m-rate'), n = Math.round(num('m-ten') * Number($('#m-unit').value));
  if (n < 1 || n > 360) { $('#e-m-ten').textContent = 'Tenure must be between 1 and 360 months.'; return; }
  const emi = calcEMI(P, rate, n), total = emi * n, interest = total - P;
  state.emi = { emi, P, interest, total };
  $('#emiOut').innerHTML = `<div class="kv"><div><small>Loan amount</small><b>${inr(P)}</b></div><div><small>Monthly EMI</small><b class="ok">${inr(emi)}</b></div>
  <div><small>Total interest</small><b class="wn">${inr(interest)}</b></div><div><small>Total payable</small><b>${inr(total)}</b></div></div>
  <div class="bar" role="img" aria-label="Principal ${(P / total * 100).toFixed(0)} percent, interest ${(interest / total * 100).toFixed(0)} percent"><i style="width:${P / total * 100}%"></i><b style="width:${interest / total * 100}%"></b></div>
  <p class="muted">Principal (blue) vs interest (amber) over ${n} months.</p>`;
  renderDash();
}

/* ---------- Dashboard ---------- */
function renderDash() {
  const L = state.loan, C = state.credit, E = state.emi;
  const score = C ? C.score : L ? L.score : null;
  const cat = C ? C.cat : score ? (score >= 750 ? 'Excellent' : score >= 700 ? 'Good' : score >= 650 ? 'Fair' : 'Needs Improvement') : '';
  const risk = C ? C.risk : L ? (L.status === 'High' ? 'Low' : L.status === 'Moderate' ? 'Medium' : 'High') : null;
  const card = (t, v, sub, cls = '') => `<div class="glass dc"><small>${t}</small><b class="${cls}">${v}</b><small>${sub}</small></div>`;
  $('#dash').innerHTML =
    card('Credit Score', score ?? '—', cat || 'Run an analysis', score ? tone(score, 750, 650) : '') +
    card('Loan Eligibility', L ? L.status : '—', L ? `Score ${L.s}/100` : 'Run an analysis', L ? (L.status === 'High' ? 'ok' : L.status === 'Moderate' ? 'wn' : 'bad') : '') +
    card('Monthly EMI', E ? inr(E.emi) : '—', 'From EMI calculator') +
    card('Debt-to-Income', L ? L.dti.toFixed(1) + '%' : '—', 'Including requested loan', L ? (L.dti <= 40 ? 'ok' : L.dti <= 50 ? 'wn' : 'bad') : '') +
    card('Financial Risk', risk ?? '—', 'Estimated', risk === 'Low' ? 'ok' : risk === 'Medium' ? 'wn' : risk ? 'bad' : '');
}

/* ---------- AI advisor ---------- */
function localAdvice(d) {
  const free = d.income - d.expenses - d.emi, rate = free / d.income * 100, dti = d.emi / d.income * 100;
  const lines = [`Financial observations\n- You keep about ${inr(Math.max(free, 0))} (${Math.max(rate, 0).toFixed(0)}%) of income after expenses and EMIs.\n- Existing EMIs use ${dti.toFixed(0)}% of income; many lenders prefer this under 40–50%.`];
  lines.push(`Budget and savings\n- A common guide is 50% needs, 30% wants, 20% savings. Build an emergency fund of 3–6 months of expenses (${inr(d.expenses * 3)}–${inr(d.expenses * 6)}).`);
  if (d.amount) lines.push(`Loan affordability\n- The requested loan adds an estimated EMI of ${inr(calcEMI(d.amount, 10.5, 60))} at 10.5% over 5 years. Compare this with your ${inr(Math.max(free, 0))} of free cash flow.`);
  lines.push(`Credit and debt\n- ${d.score >= 750 ? 'Your score is strong; keep utilization low.' : 'Improve your score with on-time payments and utilization under 30%.'}\n- Pay off the highest-interest debt first.`);
  if (d.goal) lines.push(`Your goal\n- "${d.goal}": turn it into a target amount and date, then automate a monthly transfer.`);
  return lines.join('\n\n');
}
async function getAdvice(d) {
  if (state.demo) return { text: localAdvice(d), demo: true };
  try {
    const res = await fetch('/api/financial-advice', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) });
    if (!res.ok) throw new Error('bad status');
    const j = await res.json();
    if (!j.advice || !j.advice.trim()) throw new Error('empty');
    return { text: j.advice };
  } catch {
    return { text: localAdvice(d), demo: true, failed: true };
  }
}

/* ---------- Saving records ---------- */
async function saveRecord(rec) {
  if (state.demo) return { mock: true };
  const res = await fetch('/api/save-financial-record', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(rec) });
  if (!res.ok) throw new Error('save failed');
  return res.json();
}

/* ---------- Wiring ---------- */
$('#loanForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!validateForm(e.target)) return;
  const d = { name: $('#l-name').value.trim(), age: num('l-age'), emp: $('#l-emp').value, income: num('l-inc'), expenses: num('l-exp'), emi: num('l-emi'), amount: num('l-amt'), tenure: num('l-ten'), exp: num('l-exy'), score: num('l-score'), loans: num('l-loans') };
  const r = analyzeLoan(d); state.loan = r; renderLoan(r); renderDash();
  if (!state.credit) { $('#c-score').value = d.score; }
  const msg = $('#saveMsg'); msg.textContent = '';
  if ($('#l-save').checked) {
    const risk = r.status === 'High' ? 'Low' : r.status === 'Moderate' ? 'Medium' : 'High';
    try {
      const out = await saveRecord({ name: d.name, age: d.age, employmentType: d.emp, monthlyIncome: d.income, monthlyExpenses: d.expenses, existingEmi: d.emi, creditScore: d.score, loanAmount: d.amount, loanTenure: d.tenure, eligibilityScore: r.s, eligibilityResult: r.status, riskLevel: risk });
      msg.textContent = out.mock ? 'Saved in mock mode (no data left this browser).' : 'Record saved.';
    } catch { msg.textContent = 'Your analysis is shown, but the record could not be saved. Try again later.'; }
  }
});
$('#creditForm').addEventListener('submit', e => {
  e.preventDefault();
  if (!validateForm(e.target)) return;
  const r = analyzeCredit({ score: num('c-score'), loans: num('c-loans'), pay: num('c-pay'), util: num('c-util'), acc: num('c-acc'), inq: num('c-inq') });
  state.credit = r; renderCredit(r); renderDash();
});
$('#emiForm').addEventListener('input', updateEMI);
$('#aiForm').addEventListener('submit', async e => {
  e.preventDefault();
  if (!validateForm(e.target)) return;
  const d = { income: num('a-inc'), expenses: num('a-exp'), emi: num('a-emi'), score: num('a-score'), amount: num('a-amt') || 0, emp: $('#a-emp').value, goal: $('#a-goal').value.trim().slice(0, 400) };
  const btn = $('#aiBtn'), out = $('#aiOut');
  btn.disabled = true; btn.textContent = 'Analyzing…'; out.innerHTML = '<p class="muted">Preparing your insights…</p>';
  const r = await getAdvice(d);
  out.innerHTML = `${r.demo ? '<span class="lab">Demo-generated example</span>' : ''}${r.failed ? '<p class="muted">The AI service is unavailable right now, so a built-in example is shown instead.</p>' : ''}<div class="ai"></div><p class="disc">AI-generated information is for educational purposes only and should not be considered professional financial, investment, tax, or legal advice.</p>`;
  out.querySelector('.ai').textContent = r.text;
  btn.disabled = false; btn.textContent = 'Get AI tips';
});

/* ---------- Demo mode ---------- */
function runDemo() {
  state.demo = true; $('#demoBanner').hidden = false;
  const set = (o) => Object.entries(o).forEach(([k, v]) => { $('#' + k).value = v; });
  set({ 'l-name': 'Demo User', 'l-age': 32, 'l-emp': 'Salaried', 'l-inc': 95000, 'l-exp': 35000, 'l-emi': 8000, 'l-amt': 1000000, 'l-ten': 5, 'l-exy': 6, 'l-score': 742, 'l-loans': 1,
    'c-score': 742, 'c-loans': 1, 'c-emi': 8000, 'c-pay': 0, 'c-util': 28, 'c-acc': 4, 'c-inq': 1,
    'a-inc': 95000, 'a-exp': 35000, 'a-emi': 8000, 'a-score': 742, 'a-amt': 1000000, 'a-emp': 'Salaried', 'a-goal': 'Save for a home down payment in 3 years' });
  $$('.err').forEach(x => x.textContent = '');
  $('#loanForm').requestSubmit(); $('#creditForm').requestSubmit(); updateEMI(); $('#aiForm').requestSubmit();
  $('#dashboard').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
}
$$('[data-demo]').forEach(b => b.addEventListener('click', runDemo));

/* ---------- UI polish ---------- */
const burger = $('#burger'), menu = $('#menu');
burger.addEventListener('click', () => { const o = menu.classList.toggle('open'); burger.setAttribute('aria-expanded', o); });
menu.addEventListener('click', e => { if (e.target.closest('a,button')) { menu.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); } });
function count(el) {
  const t = +el.dataset.count, suf = el.dataset.suffix || '';
  if (reduce) { el.textContent = t.toLocaleString('en-IN') + suf; return; }
  const t0 = performance.now();
  (function step(now) { const p = Math.min((now - t0) / 1200, 1); el.textContent = Math.round(t * p).toLocaleString('en-IN') + suf; if (p < 1) requestAnimationFrame(step); })(t0);
}
const io = new IntersectionObserver(es => es.forEach(x => { if (x.isIntersecting) { count(x.target); io.unobserve(x.target); } }));
$$('[data-count]').forEach(el => io.observe(el));
$('#heroEmi').textContent = inr(calcEMI(1000000, 10.75, 60)) + ' / month';
updateEMI(); renderDash();
